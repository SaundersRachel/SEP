<?php 
error_reporting(E_ALL^E_NOTICE);
	if (!isset($_SESSION)
    && !headers_sent() ) 
	{ session_start(); }
$server="localhost";
$user ="root";
$pass ="";
$db ="studentportal";
$connectionSTR = mysqli_connect($server, $user, $pass, $db);

if(!$connectionSTR)
{die("The database connection attempt was unsuccessful: " . mysqli_connect_error());}
$studentID = $_SESSION['studentID'];?>


<!DOCTYPE html>
<html lang="en">
<head>
<title>Student Profile</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<?php include 'master.php';?>
	<div class="container text-center">
	<h1>Student Profile</h1>
	
	<?php 
    $sql = "SELECT studentID as ID, studentName as Name, userID, phoneNumber as Phone, emailAddress as Email, emergencyContactName, emergencyContactPhone from student WHERE studentID = '$studentID'";
    $res = $connectionSTR->query($sql);

    while ($row = $res->fetch_assoc()) {
        foreach($row as $ind => $val)
        {
            echo "$ind:  $val<br />";
        }
        echo "<hr />";
    }





?>
	</div>
<?php include 'footer.php';?>
</body>
</html>