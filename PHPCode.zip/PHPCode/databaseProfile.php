<?php
error_reporting(E_ALL^E_NOTICE);
	if (!isset($_SESSION)
    && !headers_sent() ) 
	{ session_start(); }
$server="localhost";
$user ="root";
$pass ="";
$db ="studentportal";
$connectionSTR = mysqli_connect($server, $user, $pass, $db);

if(!$connectionSTR)
{die("The database connection attempt was unsuccessful: " . mysqli_connect_error());}
$studentID = $_SESSION['studentID'];

class Student {
	public $studentID;
	public $studentName;
	public $userID;
	public $password;
	public $phoneNumber;
	public $emailAddress;
	public $emergencyContactName;
	public $emergencyContactPhone;
	public $programID;
	public $studentStatus; }
class query {
  public $con;
  public $sql;
  function executeSelectQuery($sql) {}  }
  
if (isset($_POST['submit']))
{
	$studentName=$_POST['studentName'];
	$emailAddress=$_POST['emailAddress'];
	$phoneNumber=$_POST['phoneNumber'];
	$userID=$_POST['userID'];
	$password=$_POST['password'];
	$emergencyContactName=$_POST['emergencyContactName'];
	$emergencyContactPhone=$_POST['emergencyContactPhone'];	
	$sql3 = "
	UPDATE student 
	SET studentName = '$studentName', emailAddress = '$emailAddress', phoneNumber = '$phoneNumber', userID = '$userID', password = '$password', emergencyContactName = '$emergencyContactName', emergencyContactPhone = '$emergencyContactPhone'
	WHERE studentID = '$studentID';
	";
	
	if (mysqli_query($connectionSTR, $sql3))
	{echo "Profile Updated!";}
	else
	{echo "Error:" .$sql."".mysqli_error($connectionSTR);}
	mysqli_close($connectionSTR); }
?>