<?php	error_reporting(E_ALL^E_NOTICE);
	if (!isset($_SESSION)
    && !headers_sent() ) 
	{ session_start(); }
$server="localhost";
$user ="root";
$pass ="";
$db ="studentportal";
$connectionSTR = mysqli_connect($server, $user, $pass, $db);

if(!$connectionSTR)
{die("The database connection attempt was unsuccessful: " . mysqli_connect_error());}

if (isset($_POST['submit']))
{	$userID=$_POST['userID'];
	$password=$_POST['password'];
	$sql4 = "SELECT * from student WHERE userID = '$userID' AND password = '$password';";
	
if (empty($userID)) {
        echo 'userID is required';
exit();}

if (empty($password)) {
        echo 'Password is required';
exit();}

if($sql4 === FALSE) { 
    trigger_error(mysql_error(), E_USER_ERROR);}
$result=mysqli_query($connectionSTR, $sql4);
$numRows= mysqli_num_rows($result);
$sql = "select * from student where userID ='$userID' and password='$password';";
$query = mysqli_query($connectionSTR, $sql);

while($rs = mysqli_fetch_assoc($query)){
    $studentID = $rs['studentID'];}

  if ($numRows === 1) 
	  {	$_SESSION['login'] = "1";
		$_SESSION['userID'] = $userID;
		$_SESSION['studentID'] = $studentID;
		$_SESSION['studentName'] = $studentName;
		$_SESSION['password'] = $password;
		header("Location: profile.php");
        exit(); }
  else 	unset($_SESSION['login']);
    echo 'Login Failed.'; }?>