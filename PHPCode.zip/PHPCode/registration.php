<?php error_reporting(E_ALL ^ E_NOTICE); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Registration Page</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<?php include 'master.php';?>
	<div, require_once('databaseRegistration.php');>
	<h1>Register for the Student Enrollment Portal!</h1>
	</div>

<form action="databaseRegistration.php" method="post">
	&nbsp;&nbsp;&nbsp;Student ID: <input type="text" name="studentID" /><br />
    &nbsp;&nbsp;&nbsp;Email:  <input type="text" name="emailAddress" /><br />
	&nbsp;&nbsp;&nbsp;Name: <input type="text" name="studentName" /><br />
    &nbsp;&nbsp;&nbsp;Desired User ID:  <input type="text" name="userID" /><br />
    &nbsp;&nbsp;&nbsp;Create a Password: <input type="text" name="password" /><br />
	&nbsp;&nbsp;&nbsp;<input type="submit" name="submit" value="Register" />
	&nbsp;&nbsp;&nbsp;<input type ="reset" value = "Reset Form"><br /><br />

</form>


<?php include 'footer.php';?>
</body>
</html>