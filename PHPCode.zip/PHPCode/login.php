<?php error_reporting(E_ALL ^ E_NOTICE); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Login Page</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<?php require 'master.php';?>

	<div>
	<h1>Log In to the Student Enrollment Portal!</h1>
	</div>

<form action="databaseLogin.php" method="post">
    &nbsp;&nbsp;&nbsp;User ID:  <input type="text" name="userID" /><br />
    &nbsp;&nbsp;&nbsp;Password: <input type="text" name="password" /><br />
	&nbsp;&nbsp;&nbsp;<input type="submit" name="submit" value="Log In" />
	&nbsp;&nbsp;&nbsp;<input type ="reset" value = "Reset Form"><br /><br />
</form>

<?php include 'footer.php';?>
</body>
</html>