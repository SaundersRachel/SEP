<?php error_reporting(E_ALL^E_NOTICE);
	if (!isset($_SESSION)
    && !headers_sent() ) 
	{ session_start(); }
$server="localhost";
$user ="root";
$pass ="";
$db ="studentportal";
$connectionSTR = mysqli_connect($server, $user, $pass, $db);

if(!$connectionSTR)
{die("The database connection attempt was unsuccessful: " . mysqli_connect_error());}
$studentID = $_SESSION['studentID'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Edit Profile</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<?php include 'master.php';?>
	<div, require_once('databaseProfile.php');>
	<h1>Edit Profile</h1>
	</div>

<form action="databaseProfile.php" method="post">
	&nbsp;&nbsp;&nbsp;Name: <input type="text" name="studentName" /><br />
    &nbsp;&nbsp;&nbsp;Email:  <input type="text" name="emailAddress" /><br />
	&nbsp;&nbsp;&nbsp;Phone #: <input type="text" name="phoneNumber" /><br />
    &nbsp;&nbsp;&nbsp;User ID:  <input type="text" name="userID" /><br />
    &nbsp;&nbsp;&nbsp;Password: <input type="text" name="password" /><br />
    &nbsp;&nbsp;&nbsp;Emergency Contact Name: <input type="text" name="emergencyContactName" /><br />
    &nbsp;&nbsp;&nbsp;Emergency Contact Phone #: <input type="text" name="emergencyContactPhone" /><br />
	&nbsp;&nbsp;&nbsp;<input type="submit" name="submit" value="Save Changes" />
	&nbsp;&nbsp;&nbsp;<input type ="reset" value = "Reset Form"><br /><br />

</form>

	</div>
<?php include 'footer.php';?>
</body>
</html>