<?php 
error_reporting(E_ALL^E_NOTICE);
	if (!isset($_SESSION)
    && !headers_sent() ) 
	{ session_start(); }
$server="localhost";
$user ="root";
$pass ="";
$db ="studentportal";
$connectionSTR = mysqli_connect($server, $user, $pass, $db);

if(!$connectionSTR)
{die("The database connection attempt was unsuccessful: " . mysqli_connect_error());}
$studentID = $_SESSION['studentID'];?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Enrollment Page</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<?php include 'master.php';?>
	<div, require_once('databaseEnrollment.php');>
	<h1>Enroll in Classes Here!</h1>
	</div>

<form action="databaseEnrollment.php" method="post">
	&nbsp;&nbsp;&nbsp;Course 1 ID: <input type="text" name="course1ID" /><br />
	&nbsp;&nbsp;&nbsp;Course 2 ID: <input type="text" name="course2ID" /><br />
	&nbsp;&nbsp;&nbsp;Course 3 ID: <input type="text" name="course3ID" /><br />
	&nbsp;&nbsp;&nbsp;Course 4 ID: <input type="text" name="course4ID" /><br />
	&nbsp;&nbsp;&nbsp;Course 5 ID: <input type="text" name="course5ID" /><br />
	&nbsp;&nbsp;&nbsp;Course 6 ID: <input type="text" name="course6ID" /><br />
	&nbsp;&nbsp;&nbsp;Course 7 ID: <input type="text" name="course7ID" /><br />
	&nbsp;&nbsp;&nbsp;Course 8 ID: <input type="text" name="course8ID" /><br />
	&nbsp;&nbsp;&nbsp;Course 9 ID: <input type="text" name="course9ID" /><br />
	&nbsp;&nbsp;&nbsp;Course 10 ID: <input type="text" name="course10ID" /><br />	
	&nbsp;&nbsp;&nbsp;<input type="submit" name="submit" value="Enroll" />

</form>

<div class="container text-center">
	<h1>Schedule</h1>
		<?php ;
echo "<b>studentID: </b>";
echo $_SESSION['studentID'];
echo "<br/>";
?>
<?php
//START query schedule ID
$currentScheduleID = "SELECT currentScheduleID FROM student WHERE studentID = '$studentID'";
$resultCurrentScheduleID = mysqli_query($connectionSTR, $currentScheduleID);

if (mysqli_num_rows($resultCurrentScheduleID) > 0) {
  while($row = mysqli_fetch_assoc($resultCurrentScheduleID)) {	
$_SESSION['currentScheduleID'] = $row["currentScheduleID"];

  }
} else {
  echo "No Active Schedules Exist; Please Enroll for Classes";
}
//END query schedule ID

$sqlScheduleView = "SELECT studentID, scheduleID, course1ID, course2ID, course3ID, course4ID, course5ID, course6ID, course7ID, course8ID, course9ID, course10ID FROM semesterschedule WHERE studentID = '$studentID' AND scheduleID = '$_SESSION[currentScheduleID]'";
$resultScheduleView = mysqli_query($connectionSTR, $sqlScheduleView);

$query = array();
while($query[] = mysqli_fetch_assoc($resultScheduleView));
array_pop($query);

echo '<center><table border="1">';
echo '<tr>';
foreach($query[0] as $key => $value) {
    echo '<td>';
    echo $key;
    echo '</td>';
}
echo '</tr>';
foreach($query as $row) {
    echo '<tr>';
    foreach($row as $column) {
        echo '<td>';
        echo $column;
        echo '</td>';
    }
    echo '</tr>';
}
echo '</table><center>';



//2023-10-15 edits start here!
// ---------------------------

//Course 1 starts here
$sqlCourseNames1 = "SELECT semesterschedule.studentID as s, course.courseName as cn, course.courseStartDate as csd, course.courseEndDate as ced FROM semesterschedule INNER JOIN course ON semesterschedule.course1ID=course.courseID WHERE studentID = '$studentID' AND scheduleID = '$_SESSION[currentScheduleID]'"; 
$resultCourseNames1 = mysqli_query($connectionSTR, $sqlCourseNames1);

if (mysqli_num_rows($resultCourseNames1) > 0) {
  while($row = mysqli_fetch_assoc($resultCourseNames1)) {
	
    echo "<b>Course #1</b>";
	echo "<br/>";
	echo "Course Name: " . $row["cn"];
	echo "<br/>";
	echo "First Day of Class: " . $row["csd"]; 
	echo "<br/>";
	echo "Last Day of Class: " . $row["ced"]; 
	echo "<br/>";
  }
} else {
echo " ";
echo "<br/>";
echo "<br/>";}
//Course 1 ends here

//Course 2 starts here
$sqlCourseNames2 = "SELECT semesterschedule.studentID as s, semesterschedule.course2ID as c2id, course.courseName as cn, course.courseStartDate as csd, course.courseEndDate as ced FROM semesterschedule INNER JOIN course ON semesterschedule.course2ID=course.courseID WHERE studentID = '$studentID' AND scheduleID = '$_SESSION[currentScheduleID]'"; 
$resultCourseNames2 = mysqli_query($connectionSTR, $sqlCourseNames2);

if (mysqli_num_rows($resultCourseNames2) > 0) {
  while($row = mysqli_fetch_assoc($resultCourseNames2)) {
	
    echo "<b>Course #2</b>";
	echo "<br/>";
	echo "Course Name: " . $row["cn"];
	echo "<br/>";
	echo "First Day of Class: " . $row["csd"]; 
	echo "<br/>";
	echo "Last Day of Class: " . $row["ced"]; 
	echo "<br/>";
  }
} else {
echo " ";
echo "<br/>";
echo "<br/>";}
//Course 2 ends here

//Course 3 starts here
$sqlCourseNames3 = "SELECT semesterschedule.studentID as s, semesterschedule.course3ID as c3id, course.courseName as cn, course.courseStartDate as csd, course.courseEndDate as ced FROM semesterschedule INNER JOIN course ON semesterschedule.course3ID=course.courseID WHERE studentID = '$studentID' AND scheduleID = '$_SESSION[currentScheduleID]'"; 
$resultCourseNames3 = mysqli_query($connectionSTR, $sqlCourseNames3);

if (mysqli_num_rows($resultCourseNames3) > 0) {
  while($row = mysqli_fetch_assoc($resultCourseNames3)) {
	
    echo "<b>Course #3</b>";
	echo "<br/>";
	echo "Course Name: " . $row["cn"];
	echo "<br/>";
	echo "First Day of Class: " . $row["csd"]; 
	echo "<br/>";
	echo "Last Day of Class: " . $row["ced"]; 
	echo "<br/>";
  }
} else {
echo " ";
echo "<br/>";
echo "<br/>";}
//Course 3 ends here

//Course 4 starts here
$sqlCourseNames4 = "SELECT semesterschedule.studentID as s, semesterschedule.course4ID as c4id, course.courseName as cn, course.courseStartDate as csd, course.courseEndDate as ced FROM semesterschedule INNER JOIN course ON semesterschedule.course4ID=course.courseID WHERE studentID = '$studentID' AND scheduleID = '$_SESSION[currentScheduleID]'"; 
$resultCourseNames4 = mysqli_query($connectionSTR, $sqlCourseNames4);

if (mysqli_num_rows($resultCourseNames4) > 0) {
  while($row = mysqli_fetch_assoc($resultCourseNames4)) {
	
    echo "<b>Course #4</b>";
	echo "<br/>";
	echo "Course Name: " . $row["cn"];
	echo "<br/>";
	echo "First Day of Class: " . $row["csd"]; 
	echo "<br/>";
	echo "Last Day of Class: " . $row["ced"]; 
	echo "<br/>";
  }
} else {
echo " ";
echo "<br/>";
echo "<br/>";}
//Course 4 ends here

//Course 5 starts here
$sqlCourseNames5 = "SELECT semesterschedule.studentID as s, semesterschedule.course5ID as c5id, course.courseName as cn, course.courseStartDate as csd, course.courseEndDate as ced FROM semesterschedule INNER JOIN course ON semesterschedule.course5ID=course.courseID WHERE studentID = '$studentID' AND scheduleID = '$_SESSION[currentScheduleID]'"; 
$resultCourseNames5 = mysqli_query($connectionSTR, $sqlCourseNames5);

if (mysqli_num_rows($resultCourseNames5) > 0) {
  while($row = mysqli_fetch_assoc($resultCourseNames5)) {
	
    echo "<b>Course #5</b>";
	echo "<br/>";
	echo "Course Name: " . $row["cn"];
	echo "<br/>";
	echo "First Day of Class: " . $row["csd"]; 
	echo "<br/>";
	echo "Last Day of Class: " . $row["ced"]; 
	echo "<br/>";
  }
} else {
echo " ";
echo "<br/>";
echo "<br/>";}
//Course 5 ends here

//Course 6 starts here
$sqlCourseNames6 = "SELECT semesterschedule.studentID as s, semesterschedule.course6ID as c6id, course.courseName as cn, course.courseStartDate as csd, course.courseEndDate as ced FROM semesterschedule INNER JOIN course ON semesterschedule.course6ID=course.courseID WHERE studentID = '$studentID' AND scheduleID = '$_SESSION[currentScheduleID]'"; 
$resultCourseNames6 = mysqli_query($connectionSTR, $sqlCourseNames6);

if (mysqli_num_rows($resultCourseNames6) > 0) {
  while($row = mysqli_fetch_assoc($resultCourseNames6)) {
	
    echo "<b>Course #6</b>";
	echo "<br/>";
	echo "Course Name: " . $row["cn"];
	echo "<br/>";
	echo "First Day of Class: " . $row["csd"]; 
	echo "<br/>";
	echo "Last Day of Class: " . $row["ced"]; 
	echo "<br/>";
  }
} else {
echo " ";
echo "<br/>";
echo "<br/>";}
//Course 6 ends here

//Course 7 starts here
$sqlCourseNames7 = "SELECT semesterschedule.studentID as s, semesterschedule.course7ID as c7id, course.courseName as cn, course.courseStartDate as csd, course.courseEndDate as ced FROM semesterschedule INNER JOIN course ON semesterschedule.course7ID=course.courseID WHERE studentID = '$studentID' AND scheduleID = '$_SESSION[currentScheduleID]'"; 
$resultCourseNames7 = mysqli_query($connectionSTR, $sqlCourseNames7);

if (mysqli_num_rows($resultCourseNames7) > 0) {
  while($row = mysqli_fetch_assoc($resultCourseNames7)) {
	
    echo "<b>Course #7</b>";
	echo "<br/>";
	echo "Course Name: " . $row["cn"];
	echo "<br/>";
	echo "First Day of Class: " . $row["csd"]; 
	echo "<br/>";
	echo "Last Day of Class: " . $row["ced"]; 
	echo "<br/>";
  }
} else {
echo " ";
echo "<br/>";
echo "<br/>";}
//Course 7 ends here

//Course 8 starts here
$sqlCourseNames8 = "SELECT semesterschedule.studentID as s, semesterschedule.course8ID as c8id, course.courseName as cn, course.courseStartDate as csd, course.courseEndDate as ced FROM semesterschedule INNER JOIN course ON semesterschedule.course8ID=course.courseID WHERE studentID = '$studentID' AND scheduleID = '$_SESSION[currentScheduleID]'"; 
$resultCourseNames8 = mysqli_query($connectionSTR, $sqlCourseNames8);

if (mysqli_num_rows($resultCourseNames8) > 0) {
  while($row = mysqli_fetch_assoc($resultCourseNames8)) {
	
    echo "<b>Course #8</b>";
	echo "<br/>";
	echo "Course Name: " . $row["cn"];
	echo "<br/>";
	echo "First Day of Class: " . $row["csd"]; 
	echo "<br/>";
	echo "Last Day of Class: " . $row["ced"]; 
	echo "<br/>";
  }
} else {
echo " ";
echo "<br/>";
echo "<br/>";}
//Course 8 ends here

//Course 9 starts here
$sqlCourseNames9 = "SELECT semesterschedule.studentID as s, semesterschedule.course9ID as c9id, course.courseName as cn, course.courseStartDate as csd, course.courseEndDate as ced FROM semesterschedule INNER JOIN course ON semesterschedule.course9ID=course.courseID WHERE studentID = '$studentID' AND scheduleID = '$_SESSION[currentScheduleID]'"; 
$resultCourseNames9 = mysqli_query($connectionSTR, $sqlCourseNames9);

if (mysqli_num_rows($resultCourseNames9) > 0) {
  while($row = mysqli_fetch_assoc($resultCourseNames9)) {
	
    echo "<b>Course #9</b>";
	echo "<br/>";
	echo "Course Name: " . $row["cn"];
	echo "<br/>";
	echo "First Day of Class: " . $row["csd"]; 
	echo "<br/>";
	echo "Last Day of Class: " . $row["ced"]; 
	echo "<br/>";
  }
} else {
echo " ";
echo "<br/>";
echo "<br/>";}
//Course 9 ends here

//Course 10 starts here
$sqlCourseNames10 = "SELECT semesterschedule.studentID as s, semesterschedule.course10ID as c10id, course.courseName as cn, course.courseStartDate as csd, course.courseEndDate as ced FROM semesterschedule INNER JOIN course ON semesterschedule.course10ID=course.courseID WHERE studentID = '$studentID' AND scheduleID = '$_SESSION[currentScheduleID]'"; 
$resultCourseNames10 = mysqli_query($connectionSTR, $sqlCourseNames10);

if (mysqli_num_rows($resultCourseNames10) > 0) {
  while($row = mysqli_fetch_assoc($resultCourseNames10)) {
	
    echo "<b>Course #10</b>";
	echo "<br/>";
	echo "Course Name: " . $row["cn"];
	echo "<br/>";
	echo "First Day of Class: " . $row["csd"]; 
	echo "<br/>";
	echo "Last Day of Class: " . $row["ced"]; 
	echo "<br/>";
  }
} else {
echo " ";
echo "<br/>";
echo "<br/>";}
//Course 10 ends here

// ---------------------------
//2023-10-15 edits end here!

?>


	
	
	</div>
	<br />
<?php include 'footer.php';?>
<br />
</body>
</html>
