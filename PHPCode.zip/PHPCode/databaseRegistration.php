<?php
$server="localhost";
$user ="root";
$pass ="";
$db ="studentportal";
$connectionSTR = mysqli_connect($server, $user, $pass, $db);

if(!$connectionSTR)
{die("The database connection attempt was unsuccessful: " . mysqli_connect_error());}

class Student {
	public $studentID;
	public $studentName;
	public $userID;
	public $password;
	public $phoneNumber;
	public $emailAddress;
	public $emergencyContactName;
	public $emergencyContactPhone;
	public $programID;
	public $studentStatus; }
class query {
  public $con;
  public $sql;
  function executeSelectQuery($sql) {}  }
  
if (isset($_POST['submit']))
{
	$studentID=$_POST['studentID'];
	$emailAddress=$_POST['emailAddress'];
	$studentName=$_POST['studentName'];
	$userID=$_POST['userID'];
	$password=$_POST['password'];
	$sql3 = "INSERT INTO student (studentID,emailAddress,studentName,userID,password) VALUES ('$studentID','$emailAddress','$studentName','$userID','$password');";
	
	if (mysqli_query($connectionSTR, $sql3))
	{echo "Registration was successful!";}
	else
	{echo "Error:" .$sql."".mysqli_error($connectionSTR);}
	mysqli_close($connectionSTR); }
?>