<?php error_reporting(E_ALL^E_NOTICE);
	if (!isset($_SESSION)
    && !headers_sent() ) 
	{ session_start(); }
$server="localhost";
$user ="root";
$pass ="";
$db ="studentportal";
$connectionSTR = mysqli_connect($server, $user, $pass, $db);

if(!$connectionSTR)
{die("The database connection attempt was unsuccessful: " . mysqli_connect_error());}
$studentID = $_SESSION['studentID'];

class schedule {
	public $course1ID;
	public $course2ID;
	public $course3ID;
	public $course4ID;
	public $course5ID;
	public $course6ID;
	public $course7ID;
	public $course8ID;
	public $course9ID;
	public $course10ID;
	 }
class query {
  public $con;
  public $sql;
  function executeSelectQuery($sql) {}  }
  
if (isset($_POST['submit']))
{
	$course1ID=$_POST['course1ID'];
	$course2ID=$_POST['course2ID'];
	$course3ID=$_POST['course3ID'];
	$course4ID=$_POST['course4ID'];
	$course5ID=$_POST['course5ID'];
	$course6ID=$_POST['course6ID'];
	$course7ID=$_POST['course7ID'];
	$course8ID=$_POST['course8ID'];
	$course9ID=$_POST['course9ID'];
	$course10ID=$_POST['course10ID'];

	$sql3 = "INSERT INTO semesterschedule (studentID, course1ID, course2ID, course3ID, course4ID, course5ID, course6ID, course7ID, course8ID, course9ID, course10ID) VALUES ('$studentID','$course1ID','$course2ID','$course3ID','$course4ID','$course5ID','$course6ID','$course7ID','$course8ID','$course9ID','$course10ID');";
	
	if (mysqli_query($connectionSTR, $sql3))
	{echo "Enrollment was successful!";}
	else
	{echo "Error:" .$sql."".mysqli_error($connectionSTR);}
	mysqli_close($connectionSTR); }
	
	
	

?>