<?php
error_reporting(E_ALL ^ E_NOTICE);
if (!isset($_SESSION)
    && !headers_sent()
) {    session_start(); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale1"/>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<div class="jumbotron">
	<div class="container text-center">
	<h1>Student Enrollment Portal</h1>
	</div></div>
<nav class="navbar navbar-inverse">
	<div class = "container-fluid">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button></div>
		<div class = "collapse navbar-collapse" id="myNavbar">
			<ul class="nav navbar-nav">
				<?php
				if( isset($_SESSION['login']))
				{	
					echo '<li><a href="index.php"><span class="glyphicon glyphicon-home"></span>&nbsp;Home</a></li>';
					echo '<li><a href="profile.php"><span class="glyphicon glyphicon-user"></span>&nbsp;Student Profile</a></li>';
					echo '<li><a href="editProfile.php"><span class="glyphicon glyphicon-cog"></span>&nbsp;Edit Profile</a></li>';
					echo '<li><a href="enrollment.php"><span class="glyphicon glyphicon-education"></span>&nbsp;Enrollment</a></li>';
					echo '<li><a href="courseList.php"><span class="glyphicon glyphicon-list-alt"></span>&nbsp;Available Courses</a></li>';
					echo '<li><a href="logout.php"><span class="glyphicon glyphicon-off"></span> Log Out</a></li>';}
				else
				{	
					echo '<li><a href="index.php"><span class="glyphicon glyphicon-home"></span>&nbsp;Home</a></li>';
					echo '<li><a href="login.php"><span class="glyphicon glyphicon-user"></span>&nbsp;Log In</a></li>';
					echo '<li><a href="registration.php"><span class="glyphicon glyphicon-pencil"></span>&nbsp;Create An Account</a></li>';}
				?>
			</ul>		</div>	</div></nav></body></html>